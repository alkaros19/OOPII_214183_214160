
package gr.mycities.recommendation;

import java.util.ArrayList;
import java.util.List;


public class MyTerms {
    public static List<String> terms = new ArrayList<String>();
}
